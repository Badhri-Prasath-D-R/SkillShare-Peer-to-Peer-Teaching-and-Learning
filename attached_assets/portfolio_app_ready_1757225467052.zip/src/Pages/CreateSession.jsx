import React, { useState } from "react";
import { Session } from "@/entities/Session";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

const skillCategories = [
  { value: "programming", label: "Programming" },
  { value: "design", label: "Design" },
  { value: "business", label: "Business" },
  { value: "language", label: "Language" },
  { value: "music", label: "Music" },
  { value: "writing", label: "Writing" },
  { value: "cooking", label: "Cooking" },
  { value: "fitness", label: "Fitness" },
  { value: "photography", label: "Photography" },
  { value: "marketing", label: "Marketing" },
  { value: "data_science", label: "Data Science" },
  { value: "art", label: "Art" },
  { value: "public_speaking", label: "Public Speaking" },
  { value: "other", label: "Other" }
];

export default function CreateSession() {
  const navigate = useNavigate();
  const [isCreating, setIsCreating] = useState(false);
  const [tags, setTags] = useState([]);
  const [newTag, setNewTag] = useState("");
  const [sessionData, setSessionData] = useState({
    title: "",
    description: "",
    skill_category: "",
    date: "",
    time: "",
    duration: 60,
    max_participants: 10,
    session_type: "live_video",
    difficulty_level: "beginner",
    cost_points: 2
  });

  const handleInputChange = (field, value) => {
    setSessionData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags(prev => [...prev, newTag.trim()]);
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove) => {
    setTags(prev => prev.filter(tag => tag !== tagToRemove));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsCreating(true);

    try {
      const user = await User.me();
      
      const newSession = {
        ...sessionData,
        host_email: user.email,
        host_name: user.full_name,
        tags: tags,
        status: "upcoming",
        current_participants: 0,
        participant_emails: []
      };

      await Session.create(newSession);
      
      // Update user's session count
      await User.updateMyUserData({
        sessions_hosted: (user.sessions_hosted || 0) + 1,
        points: (user.points || 10) + 5 // Reward points for hosting
      });

      alert("Session created successfully!");
      navigate(createPageUrl("Dashboard"));
    } catch (error) {
      console.error("Error creating session:", error);
      alert("Error creating session. Please try again.");
    }
    setIsCreating(false);
  };

  // Get today's date in YYYY-MM-DD format
  const today = format(new Date(), 'yyyy-MM-dd');

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="hover:bg-orange-100"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">
              Create Knowledge Session
            </h1>
            <p className="text-gray-600 mt-1">Share your expertise with the community</p>
          </div>
        </div>

        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader className="pb-6">
            <CardTitle className="text-2xl text-gray-900">Session Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title" className="text-base font-semibold">Session Title*</Label>
                <Input
                  id="title"
                  value={sessionData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  placeholder="e.g., Introduction to React Hooks"
                  className="text-lg py-3"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-base font-semibold">Description*</Label>
                <Textarea
                  id="description"
                  value={sessionData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="What will participants learn? What topics will you cover?"
                  className="h-32"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Skill Category*</Label>
                  <Select
                    value={sessionData.skill_category}
                    onValueChange={(value) => handleInputChange('skill_category', value)}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {skillCategories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-semibold">Difficulty Level</Label>
                  <Select
                    value={sessionData.difficulty_level}
                    onValueChange={(value) => handleInputChange('difficulty_level', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="date" className="text-base font-semibold">Date*</Label>
                  <Input
                    id="date"
                    type="date"
                    min={today}
                    value={sessionData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time" className="text-base font-semibold">Time*</Label>
                  <Input
                    id="time"
                    type="time"
                    value={sessionData.time}
                    onChange={(e) => handleInputChange('time', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="duration" className="text-base font-semibold">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    min="15"
                    max="180"
                    value={sessionData.duration}
                    onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="max_participants" className="text-base font-semibold">Max Participants</Label>
                  <Input
                    id="max_participants"
                    type="number"
                    min="2"
                    max="50"
                    value={sessionData.max_participants}
                    onChange={(e) => handleInputChange('max_participants', parseInt(e.target.value))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cost_points" className="text-base font-semibold">Cost (Points)</Label>
                  <Input
                    id="cost_points"
                    type="number"
                    min="1"
                    max="10"
                    value={sessionData.cost_points}
                    onChange={(e) => handleInputChange('cost_points', parseInt(e.target.value))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-base font-semibold">Session Type</Label>
                <Select
                  value={sessionData.session_type}
                  onValueChange={(value) => handleInputChange('session_type', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="live_video">Live Video Session</SelectItem>
                    <SelectItem value="screen_share">Screen Share + Discussion</SelectItem>
                    <SelectItem value="text_discussion">Text-based Discussion</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-base font-semibold">Tags (Optional)</Label>
                <div className="flex gap-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Add a tag..."
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={addTag}
                    className="shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                {tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="flex items-center gap-1">
                        {tag}
                        <button
                          type="button"
                          onClick={() => removeTag(tag)}
                          className="ml-1 hover:bg-gray-300 rounded-full p-1"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-4 pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate(createPageUrl("Dashboard"))}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isCreating}
                  className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 px-8"
                >
                  {isCreating ? "Creating..." : "Create Session"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}