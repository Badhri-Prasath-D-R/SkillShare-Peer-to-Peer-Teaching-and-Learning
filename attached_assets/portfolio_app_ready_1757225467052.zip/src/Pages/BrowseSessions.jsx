
import React, { useState, useEffect, useCallback } from "react";
import { Session } from "@/entities/Session";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Filter, Calendar, Clock, Users, Star } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

const skillCategories = [
  { value: "all", label: "All Categories" },
  { value: "programming", label: "Programming" },
  { value: "design", label: "Design" },
  { value: "business", label: "Business" },
  { value: "language", label: "Language" },
  { value: "music", label: "Music" },
  { value: "writing", label: "Writing" },
  { value: "cooking", label: "Cooking" },
  { value: "fitness", label: "Fitness" },
  { value: "photography", label: "Photography" },
  { value: "marketing", label: "Marketing" },
  { value: "data_science", label: "Data Science" },
  { value: "art", label: "Art" },
  { value: "public_speaking", label: "Public Speaking" },
  { value: "other", label: "Other" }
];

const skillColors = {
  programming: "bg-blue-100 text-blue-800 border-blue-200",
  design: "bg-purple-100 text-purple-800 border-purple-200", 
  business: "bg-green-100 text-green-800 border-green-200",
  language: "bg-yellow-100 text-yellow-800 border-yellow-200",
  music: "bg-pink-100 text-pink-800 border-pink-200",
  writing: "bg-indigo-100 text-indigo-800 border-indigo-200",
  cooking: "bg-orange-100 text-orange-800 border-orange-200",
  fitness: "bg-red-100 text-red-800 border-red-200",
  photography: "bg-cyan-100 text-cyan-800 border-cyan-200",
  marketing: "bg-teal-100 text-teal-800 border-teal-200",
  data_science: "bg-violet-100 text-violet-800 border-violet-200",
  art: "bg-rose-100 text-rose-800 border-rose-200",
  public_speaking: "bg-amber-100 text-amber-800 border-amber-200",
  other: "bg-gray-100 text-gray-800 border-gray-200"
};

export default function BrowseSessions() {
  const [sessions, setSessions] = useState([]);
  const [filteredSessions, setFilteredSessions] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [difficultyFilter, setDifficultyFilter] = useState("all");

  const loadSessionsAndUser = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const allSessions = await Session.filter(
        { status: "upcoming" },
        "-created_date",
        50
      );
      setSessions(allSessions);
    } catch (error) {
      console.error("Error loading sessions:", error);
    }
    setIsLoading(false);
  };

  const filterSessions = useCallback(() => {
    let filtered = sessions;

    if (searchTerm) {
      filtered = filtered.filter(session =>
        session.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.host_name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter !== "all") {
      filtered = filtered.filter(session => session.skill_category === categoryFilter);
    }

    if (difficultyFilter !== "all") {
      filtered = filtered.filter(session => session.difficulty_level === difficultyFilter);
    }

    setFilteredSessions(filtered);
  }, [sessions, searchTerm, categoryFilter, difficultyFilter]);

  useEffect(() => {
    loadSessionsAndUser();
  }, []);

  useEffect(() => {
    filterSessions();
  }, [filterSessions]);

  const handleJoinSession = async (sessionId) => {
    try {
      const session = sessions.find(s => s.id === sessionId);
      if (!session || !user) return;

      if (user.points < session.cost_points) {
        alert("You don't have enough points to join this session!");
        return;
      }

      if (session.current_participants >= session.max_participants) {
        alert("This session is full!");
        return;
      }

      const updatedSession = {
        ...session,
        current_participants: session.current_participants + 1,
        participant_emails: [...(session.participant_emails || []), user.email]
      };

      await Session.update(sessionId, updatedSession);
      
      // Update user points
      await User.updateMyUserData({
        points: user.points - session.cost_points,
        sessions_attended: (user.sessions_attended || 0) + 1
      });

      alert("Successfully joined the session!");
      loadSessionsAndUser();
    } catch (error) {
      console.error("Error joining session:", error);
      alert("Error joining session. Please try again.");
    }
  };

  const handleUnenrollSession = async (sessionId) => {
    try {
      const session = sessions.find(s => s.id === sessionId);
      if (!session || !user) return;

      if (!session.participant_emails?.includes(user.email)) {
        alert("You are not enrolled in this session.");
        return;
      }

      const updatedSession = {
        ...session,
        current_participants: session.current_participants - 1,
        participant_emails: (session.participant_emails || []).filter(email => email !== user.email)
      };

      await Session.update(sessionId, updatedSession);
      
      // Refund points and update user stats
      await User.updateMyUserData({
        points: (user.points || 0) + session.cost_points,
        sessions_attended: Math.max(0, (user.sessions_attended || 0) - 1)
      });

      alert("Successfully unenrolled from the session!");
      loadSessionsAndUser();
    } catch (error) {
      console.error("Error unenrolling from session:", error);
      alert("Error unenrolling from session. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent mb-2">
            Browse Knowledge Sessions
          </h1>
          <p className="text-gray-600 text-lg">Discover amazing learning opportunities from the community</p>
        </div>

        {/* Filters */}
        <Card className="mb-8 shadow-lg border-0 bg-white/90 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search sessions, topics, or hosts..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {skillCategories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="mb-4 flex items-center justify-between">
          <p className="text-gray-600">
            {isLoading ? "Loading..." : `${filteredSessions.length} sessions found`}
          </p>
          {user && (
            <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">
              You have {user.points || 0} points
            </Badge>
          )}
        </div>

        {/* Sessions Grid */}
        <div className="grid gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="p-6">
                <div className="flex items-start gap-4">
                  <Skeleton className="w-16 h-16 rounded-full" />
                  <div className="flex-1 space-y-3">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <div className="flex gap-2">
                      <Skeleton className="h-6 w-20" />
                      <Skeleton className="h-6 w-16" />
                    </div>
                  </div>
                  <Skeleton className="h-10 w-24" />
                </div>
              </Card>
            ))
          ) : filteredSessions.length > 0 ? (
            filteredSessions.map((session) => (
              <Card key={session.id} className="shadow-lg border-0 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-16 h-16 border-2 border-gray-200">
                      <AvatarFallback className="bg-gradient-to-r from-orange-400 to-pink-400 text-white font-semibold text-lg">
                        {session.host_name?.split(' ').map(n => n[0]).join('') || 'H'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{session.title}</h3>
                      <p className="text-gray-600 mb-3 line-clamp-2">{session.description}</p>
                      
                      <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500 mb-4">
                        <span className="flex items-center gap-1 font-medium">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(session.date + 'T' + session.time), "MMM d, h:mm a")}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {session.duration}min
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {session.current_participants}/{session.max_participants}
                        </span>
                        {session.rating_average > 0 && (
                          <span className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-500" />
                            {session.rating_average.toFixed(1)}
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <Badge className={`${skillColors[session.skill_category]} border`}>
                          {session.skill_category.replace('_', ' ')}
                        </Badge>
                        <Badge variant="outline" className="capitalize">
                          {session.difficulty_level}
                        </Badge>
                        <Badge variant="outline">
                          {session.cost_points} points
                        </Badge>
                        <Badge variant="outline" className="capitalize">
                          {session.session_type.replace('_', ' ')}
                        </Badge>
                        {session.tags?.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 items-end">
                      <p className="text-sm text-gray-500 text-right">
                        by <span className="font-medium">{session.host_name}</span>
                      </p>
                      {(() => {
                        if (!user) return null;
                        if (session.host_email === user.email) {
                          return (
                            <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                              Your Session
                            </Badge>
                          );
                        }
                        if (session.participant_emails?.includes(user.email)) {
                          return (
                            <Button
                              variant="outline"
                              onClick={() => handleUnenrollSession(session.id)}
                              className="border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700"
                            >
                              Unenroll
                            </Button>
                          );
                        }
                        return (
                          <Button
                            onClick={() => handleJoinSession(session.id)}
                            disabled={session.current_participants >= session.max_participants}
                            className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
                          >
                            {session.current_participants >= session.max_participants ? "Full" : "Join Session"}
                          </Button>
                        );
                      })()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card className="p-12 text-center">
              <div className="max-w-md mx-auto">
                <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No sessions found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your search terms or filters to discover more learning opportunities.
                </p>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("");
                    setCategoryFilter("all");
                    setDifficultyFilter("all");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
