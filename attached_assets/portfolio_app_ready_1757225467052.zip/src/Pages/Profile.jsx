import React, { useState, useEffect } from "react";
import { User } from "@/entities/User";
import { Session } from "@/entities/Session";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  User as UserIcon, 
  BookOpen, 
  Target, 
  Plus, 
  X, 
  Star,
  Users,
  Calendar,
  Award
} from "lucide-react";
import { Label } from "@/components/ui/label";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [userSessions, setUserSessions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    bio: "",
    skills_known: [],
    skills_wanted: []
  });
  const [newSkillKnown, setNewSkillKnown] = useState("");
  const [newSkillWanted, setNewSkillWanted] = useState("");

  useEffect(() => {
    loadProfileData();
  }, []);

  const loadProfileData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setEditData({
        bio: currentUser.bio || "",
        skills_known: currentUser.skills_known || [],
        skills_wanted: currentUser.skills_wanted || []
      });

      const sessions = await Session.filter(
        { host_email: currentUser.email },
        "-created_date",
        20
      );
      setUserSessions(sessions);
    } catch (error) {
      console.error("Error loading profile:", error);
    }
    setIsLoading(false);
  };

  const handleSaveProfile = async () => {
    try {
      await User.updateMyUserData(editData);
      setUser(prev => ({ ...prev, ...editData }));
      setIsEditing(false);
      alert("Profile updated successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("Error updating profile. Please try again.");
    }
  };

  const addSkillKnown = () => {
    if (newSkillKnown.trim() && !editData.skills_known.includes(newSkillKnown.trim())) {
      setEditData(prev => ({
        ...prev,
        skills_known: [...prev.skills_known, newSkillKnown.trim()]
      }));
      setNewSkillKnown("");
    }
  };

  const addSkillWanted = () => {
    if (newSkillWanted.trim() && !editData.skills_wanted.includes(newSkillWanted.trim())) {
      setEditData(prev => ({
        ...prev,
        skills_wanted: [...prev.skills_wanted, newSkillWanted.trim()]
      }));
      setNewSkillWanted("");
    }
  };

  const removeSkillKnown = (skill) => {
    setEditData(prev => ({
      ...prev,
      skills_known: prev.skills_known.filter(s => s !== skill)
    }));
  };

  const removeSkillWanted = (skill) => {
    setEditData(prev => ({
      ...prev,
      skills_wanted: prev.skills_wanted.filter(s => s !== skill)
    }));
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent mb-2">
            Your Profile
          </h1>
          <p className="text-gray-600 text-lg">Manage your skills and learning journey</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Info */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <UserIcon className="w-5 h-5 text-orange-600" />
                  Profile Information
                </CardTitle>
                <Button
                  variant="outline"
                  onClick={() => setIsEditing(!isEditing)}
                  className="hover:bg-orange-50"
                >
                  {isEditing ? "Cancel" : "Edit Profile"}
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-6">
                  <Avatar className="w-24 h-24 border-4 border-orange-200">
                    <AvatarImage src={user.profile_image} />
                    <AvatarFallback className="bg-gradient-to-r from-orange-400 to-pink-400 text-white font-bold text-2xl">
                      {user.full_name?.split(' ').map(n => n[0]).join('') || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{user.full_name}</h2>
                    <p className="text-gray-600">{user.email}</p>
                    <Badge variant="outline" className="mt-1 capitalize">
                      {user.role}
                    </Badge>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-semibold mb-2 block">Bio</Label>
                  {isEditing ? (
                    <Textarea
                      value={editData.bio}
                      onChange={(e) => setEditData(prev => ({ ...prev, bio: e.target.value }))}
                      placeholder="Tell the community about yourself..."
                      className="h-24"
                    />
                  ) : (
                    <p className="text-gray-600">
                      {user.bio || "No bio added yet. Share something about yourself!"}
                    </p>
                  )}
                </div>

                <div>
                  <Label className="text-base font-semibold mb-3 block flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                    Skills You Can Teach
                  </Label>
                  {isEditing ? (
                    <>
                      <div className="flex gap-2 mb-3">
                        <Input
                          value={newSkillKnown}
                          onChange={(e) => setNewSkillKnown(e.target.value)}
                          placeholder="Add a skill you can teach..."
                          onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkillKnown())}
                        />
                        <Button type="button" onClick={addSkillKnown} variant="outline">
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {editData.skills_known.map((skill, index) => (
                          <Badge key={index} className="bg-green-100 text-green-800 border-green-200 flex items-center gap-1">
                            {skill}
                            <button onClick={() => removeSkillKnown(skill)}>
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {user.skills_known?.length > 0 ? (
                        user.skills_known.map((skill, index) => (
                          <Badge key={index} className="bg-green-100 text-green-800 border-green-200">
                            {skill}
                          </Badge>
                        ))
                      ) : (
                        <p className="text-gray-500 italic">No skills added yet</p>
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-base font-semibold mb-3 block flex items-center gap-2">
                    <div className="w-3 h-3 bg-blue-500 rounded-full" />
                    Skills You Want to Learn
                  </Label>
                  {isEditing ? (
                    <>
                      <div className="flex gap-2 mb-3">
                        <Input
                          value={newSkillWanted}
                          onChange={(e) => setNewSkillWanted(e.target.value)}
                          placeholder="Add a skill you want to learn..."
                          onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkillWanted())}
                        />
                        <Button type="button" onClick={addSkillWanted} variant="outline">
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {editData.skills_wanted.map((skill, index) => (
                          <Badge key={index} className="bg-blue-100 text-blue-800 border-blue-200 flex items-center gap-1">
                            <Target className="w-3 h-3" />
                            {skill}
                            <button onClick={() => removeSkillWanted(skill)}>
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {user.skills_wanted?.length > 0 ? (
                        user.skills_wanted.map((skill, index) => (
                          <Badge key={index} className="bg-blue-100 text-blue-800 border-blue-200">
                            <Target className="w-3 h-3 mr-1" />
                            {skill}
                          </Badge>
                        ))
                      ) : (
                        <p className="text-gray-500 italic">No learning goals set</p>
                      )}
                    </div>
                  )}
                </div>

                {isEditing && (
                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button variant="outline" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleSaveProfile} className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600">
                      Save Changes
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Stats & Sessions */}
          <div className="space-y-6">
            <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-orange-600" />
                  Your Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <span className="flex items-center gap-2 text-gray-700">
                    <BookOpen className="w-4 h-4" />
                    Learning Points
                  </span>
                  <span className="font-bold text-orange-600 text-lg">{user.points || 10}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="flex items-center gap-2 text-gray-700">
                    <Users className="w-4 h-4" />
                    Sessions Hosted
                  </span>
                  <span className="font-bold text-green-600 text-lg">{user.sessions_hosted || 0}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span className="flex items-center gap-2 text-gray-700">
                    <Target className="w-4 h-4" />
                    Sessions Attended
                  </span>
                  <span className="font-bold text-blue-600 text-lg">{user.sessions_attended || 0}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                  <span className="flex items-center gap-2 text-gray-700">
                    <Star className="w-4 h-4" />
                    Average Rating
                  </span>
                  <span className="font-bold text-yellow-600 text-lg">
                    {user.average_rating ? `⭐ ${user.average_rating.toFixed(1)}` : "No ratings"}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-orange-600" />
                  Your Sessions ({userSessions.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {userSessions.length > 0 ? (
                  <div className="space-y-3">
                    {userSessions.slice(0, 5).map((session) => (
                      <div key={session.id} className="p-3 border border-gray-200 rounded-lg bg-white/50">
                        <h4 className="font-medium text-gray-900 text-sm">{session.title}</h4>
                        <div className="flex items-center justify-between mt-2">
                          <Badge variant="outline" className="text-xs capitalize">
                            {session.status}
                          </Badge>
                          <span className="text-xs text-gray-500 flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {session.current_participants}
                          </span>
                        </div>
                      </div>
                    ))}
                    {userSessions.length > 5 && (
                      <p className="text-xs text-gray-500 text-center">
                        ...and {userSessions.length - 5} more sessions
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-sm">No sessions hosted yet</p>
                    <p className="text-xs">Start sharing your knowledge!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}