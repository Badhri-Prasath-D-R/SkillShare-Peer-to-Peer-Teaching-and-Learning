import React, { useState, useEffect } from "react";
import { Session } from "@/entities/Session";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Users, 
  Clock, 
  Star, 
  BookOpen, 
  Plus, 
  Calendar,
  TrendingUp,
  Award,
  Target
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

import StatsCards from "../components/dashboard/StatsCards";
import FeaturedSessions from "../components/dashboard/FeaturedSessions";
import RecentActivity from "../components/dashboard/RecentActivity";
import SkillsOverview from "../components/dashboard/SkillsOverview";

export default function Dashboard() {
  const [upcomingSessions, setUpcomingSessions] = useState([]);
  const [user, setUser] = useState(null);
  const [mySessions, setMySessions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const sessions = await Session.filter(
        { status: "upcoming" },
        "-created_date",
        8
      );
      setUpcomingSessions(sessions);

      const userSessions = await Session.filter(
        { host_email: currentUser.email },
        "-created_date",
        5
      );
      setMySessions(userSessions);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">
              Welcome back{user ? `, ${user.full_name?.split(' ')[0]}` : ''}! 
            </h1>
            <p className="text-gray-600 mt-2 text-lg">Ready to learn something new or share your expertise?</p>
          </div>
          <Link to={createPageUrl("CreateSession")} className="w-full md:w-auto">
            <Button className="w-full md:w-auto bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white shadow-lg transition-all duration-300 transform hover:scale-105">
              <Plus className="w-5 h-5 mr-2" />
              Host a Session
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCards 
            title="Your Points" 
            value={user?.points || 10}
            icon={BookOpen}
            bgColor="bg-orange-500"
            trend="+2 this week"
          />
          <StatsCards 
            title="Sessions Hosted" 
            value={user?.sessions_hosted || 0}
            icon={Users}
            bgColor="bg-pink-500"
            trend="All time"
          />
          <StatsCards 
            title="Sessions Attended" 
            value={user?.sessions_attended || 0}
            icon={Target}
            bgColor="bg-purple-500"
            trend="Keep learning!"
          />
          <StatsCards 
            title="Your Rating" 
            value={user?.average_rating ? `⭐ ${user.average_rating.toFixed(1)}` : "No ratings yet"}
            icon={Award}
            bgColor="bg-blue-500"
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <FeaturedSessions 
              sessions={upcomingSessions}
              isLoading={isLoading}
              user={user}
            />
            
            <SkillsOverview user={user} />
          </div>

          <div className="space-y-8">
            <RecentActivity 
              mySessions={mySessions}
              isLoading={isLoading}
            />

            <Card className="overflow-hidden shadow-lg border-0 bg-gradient-to-br from-blue-50 to-indigo-100">
              <CardHeader className="pb-3">
                <CardTitle className="text-xl font-bold text-gray-900 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to={createPageUrl("BrowseSessions")} className="block">
                  <Button variant="outline" className="w-full justify-start hover:bg-white/80 transition-all duration-200">
                    <Calendar className="w-4 h-4 mr-3" />
                    Browse All Sessions
                  </Button>
                </Link>
                <Link to={createPageUrl("Profile")} className="block">
                  <Button variant="outline" className="w-full justify-start hover:bg-white/80 transition-all duration-200">
                    <Users className="w-4 h-4 mr-3" />
                    Update Your Skills
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}